//! Picture-in-picture: the player in a small always-on-top window that stays
//! visible over other apps.
use super::slot::SlotFollower;
use crate::player::controller::player;
use crate::player::view::PlayerView;
use crate::ui::*;
use gpui_kit::component::button::Button;

#[derive(Default)]
struct PipWindow(Option<AnyWindowHandle>);
impl Global for PipWindow {}

pub struct PipView {
    view: Entity<PlayerView>,
}

pub fn handle(cx: &App) -> Option<AnyWindowHandle> {
    cx.try_global::<PipWindow>().and_then(|p| p.0)
}

pub fn open(cx: &mut App) {
    if let Some(h) = cx.try_global::<PipWindow>().and_then(|p| p.0) {
        if h.update(cx, |_, window, _| window.activate_window()).is_ok() {
            return;
        }
    }
    let size = size(px(480.), px(270.));
    let origin = cx
        .primary_display()
        .map(|d| {
            let b = d.bounds();
            point(b.origin.x + b.size.width - size.width - px(24.), b.origin.y + b.size.height - size.height - px(72.))
        })
        .unwrap_or(point(px(80.), px(80.)));
    let opts = WindowOptions {
        window_bounds: Some(WindowBounds::Windowed(Bounds::new(origin, size))),
        titlebar: None,
        kind: WindowKind::PopUp,
        // Keep the main window active when ordering the Mac panel onscreen.
        focus: !cfg!(target_os = "macos"),
        is_resizable: true,
        is_minimizable: false,
        window_min_size: Some(gpui_kit::size(px(256.), px(144.))),
        ..Default::default()
    };
    let res = gpui_kit::open_window(opts, cx, |_window, cx| {
        #[cfg(target_os = "macos")]
        {
            _window.set_window_title("Picture in Picture");
            crate::macos::configure_pip_window(_window);
        }
        let pl = player(cx);
        let view = cx.new(|cx| {
            let mut v = PlayerView::new(pl, false, cx);
            v.pip = true;
            v
        });
        cx.new(|_| PipView { view })
    });
    match res {
        Ok((h, _)) => cx.set_global(PipWindow(Some(h))),
        Err(e) => toast(cx, crate::ui::friendly_error(&e.to_string())),
    }
    cx.refresh_windows();
}

pub fn window_closed(id: WindowId, cx: &mut App) {
    if handle(cx).is_some_and(|panel| panel.window_id() == id) {
        cx.set_global(PipWindow(None));
        cx.refresh_windows();
    }
}

pub(super) fn main_surface(view: &Entity<PlayerView>, cx: &App) -> SlotFollower {
    let content = if handle(cx).is_some() {
        placeholder().into_any_element()
    } else {
        view.clone().into_any_element()
    };
    SlotFollower::new(cx, content)
}

fn placeholder() -> impl IntoElement {
    div()
        .size_full()
        .bg(black())
        .text_color(white())
        .flex()
        .flex_col()
        .items_center()
        .justify_center()
        .gap_3()
        .child(icon("picture-in-picture").size_8())
        .child("Playing in Picture in Picture")
        .child(Button::new("return-from-pip").label("Return to player").on_click(|_, _, cx| {
            if let Some(panel) = handle(cx) {
                let _ = panel.update(cx, |_, window, _| window.remove_window());
            }
        }))
}

impl Render for PipView {
    fn render(&mut self, _window: &mut Window, _cx: &mut Context<Self>) -> impl IntoElement {
        div()
            .id("pip")
            .group("pip")
            .relative()
            .size_full()
            .bg(black())
            .child(self.view.clone())
            // top strip: drag to move, close button
            .child(
                div()
                    .absolute()
                    .top_0()
                    .left_0()
                    .right_0()
                    .h(px(32.))
                    .flex()
                    .items_center()
                    .justify_end()
                    .invisible()
                    .group_hover("pip", |s| s.visible())
                    .bg(linear_gradient(180., linear_color_stop(hsla(0., 0., 0., 0.6), 0.), linear_color_stop(hsla(0., 0., 0., 0.), 1.)))
                    .child({
                        let drag = div().id("pip-drag").flex_1().h_full();
                        #[cfg(target_os = "macos")]
                        let drag = drag.on_mouse_down(MouseButton::Left, |_, window, cx| {
                            cx.stop_propagation();
                            window.start_window_move();
                        });
                        #[cfg(not(target_os = "macos"))]
                        let drag = drag.window_control_area(WindowControlArea::Drag);
                        drag
                    })
                    .child(
                        div()
                            .id("pip-close")
                            .flex()
                            .items_center()
                            .justify_center()
                            .size(px(32.))
                            .cursor_pointer()
                            .hover(|s| s.bg(hsla(0., 0., 1., 0.15)))
                            .child(icon("x").size_4().text_color(white()))
                            .on_click(|_, window, cx| {
                                cx.stop_propagation();
                                window.remove_window();
                            }),
                    ),
            )
    }
}

#[cfg(test)]
mod tests;
